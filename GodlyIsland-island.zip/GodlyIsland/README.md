# Godly Island

Dynamic Island cho Android (Kotlin + Jetpack Compose): kính lỏng nhiều màu "hút vào" lấy từ `Godly-Watermark.html`, icon tự vẽ, kiểu iPhone 14 Pro Max (đen), chỉnh được chiều ngang/cao.

## Tình trạng hiện tại (trung thực)

| Phần | Trạng thái |
|---|---|
| Island thật (overlay + service + quyền) | Code xong, **chưa biên dịch, chưa chạy trên máy** |
| Kính Godly Color (shader AGSL thủ tục, "hút vào", bỏ ripple, bỏ bóng láng) | Shader đã chạy thử trong WebGL; AGSL trên Android chưa thử |
| Kiểu iPhone 14 Pro Max (đen thuần) | Code xong, chưa chạy máy |
| 12 icon tự vẽ (không emoji) | Đã vẽ + xem trước (`docs/design_icons.png`) |
| Chỉnh kích thước ngang/cao Mini / Expanded / Full + vị trí | Code xong, chưa chạy máy |
| Sự kiện **thật** | Chỉ **pin** (sạc, pin yếu 20%/10%, pin đầy) |
| Thông báo, nhạc, cuộc gọi, điều hướng, hẹn giờ, Bluetooth, tải xuống thật | **Chưa làm** (chỉ có giả lập trong Test Mode) |

Môi trường soạn code không có Android SDK/Gradle/Kotlin/mạng nên APK chưa được build ở đây. Hãy build bằng GitHub Actions (`BUILD.md`) rồi chạy Test Mode.

## Vì sao Island này không lag (thiết kế)

- Mọi giá trị animation chỉ được đọc ở bước layout/draw → không recompose mỗi frame.
- Nội dung bố cục một lần ở kích thước cuối, viên đảo lớn dần rồi "mở" nội dung (clip + fade) → chữ không bị đo lại khi đang chuyển.
- Thân kính là **một lần vẽ shader thủ tục**, không layer ngoài màn hình, không đọc texture. Kiểu đen thì chỉ là Canvas.
- Cửa sổ overlay chỉ đổi kích thước **trước khi** phóng to và **sau khi** thu nhỏ, không đổi từng frame.
- Không ripple, không bóng láng, không animation vô hạn. Đứng yên thì không tạo frame nào.
- Test Mode đo chuyển cảnh bằng Choreographer (frame, trung bình, p95, tệ nhất, frame rớt) — số thật, không ước lượng.

## Cấu trúc

```
app/src/main/
  assets/island_material.agsl       thân Island (thủ tục, lens hút vào)
  assets/liquid_glass.agsl          lab kính lấy mẫu nền (Test Mode)
  java/com/godly/island/
    MainActivity.kt                 bật/tắt Island, trạng thái
    island/                         IslandView, IslandShape, IslandSettings, IslandPalette, IconArt + IslandIcons,
                                    IslandEventManager, IslandStateManager, IslandAnimationController,
                                    IslandWindowManager, GodlyIslandService, IslandLauncher
    renderer/                       IslandMaterial, LiquidGlassRenderer (lab), GlassConfig
    battery/                        BatteryEventSource (sự kiện pin thật)
    events/                         IslandEvent, IslandKind
    settings/                       IslandSettingsActivity, GlassSettingsStore
    testing/                        Test Mode (panel, simulator, preview)
    core/                           theme, UI chung, ErrorLog, PerfMonitor
docs/                               phân tích, kế hoạch, hướng dẫn, ảnh thiết kế
.github/workflows/build-apk.yml     build APK debug (tự giải nén zip nếu cần)
```

## Tài liệu

`BUILD.md` · `INSTALL.md` · `docs/CHANGELOG.md` · `docs/PLAN.md` · `docs/ANALYSIS_LIQUID_GLASS.md` · `docs/PERMISSIONS.md` · `docs/DEBUG.md` · `docs/TEST_GUIDE.md`
