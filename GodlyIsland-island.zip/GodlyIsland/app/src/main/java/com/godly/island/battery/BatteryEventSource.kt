package com.godly.island.battery

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.content.ContextCompat
import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind
import com.godly.island.island.IslandEventManager

/**
 * REAL battery events from the system (no permission needed):
 * plug-in -> "Đang sạc", unplug -> removed, falling to 20% / 10% -> low-battery warning, 100% -> full.
 * It reports what Android says; it does not guess "fast charging".
 */
class BatteryEventSource(private val context: Context) {
    private var lastPlugged = -1
    private var lastLevel = -1
    private var started = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            if (intent != null) handle(intent, false)
        }
    }

    fun start() {
        if (started) return
        started = true
        val sticky = ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        if (sticky != null) handle(sticky, true) // remember the starting state, show nothing
    }

    fun stop() {
        if (!started) return
        started = false
        try {
            context.unregisterReceiver(receiver)
        } catch (_: Throwable) {
        }
    }

    private fun handle(intent: Intent, initial: Boolean) {
        val rawLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        if (rawLevel < 0 || scale <= 0) return
        val level = rawLevel * 100 / scale

        if (!initial) {
            if (plugged != 0 && lastPlugged == 0) {
                val how = when (plugged) {
                    BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Sạc không dây"
                    BatteryManager.BATTERY_PLUGGED_USB -> "Sạc qua USB"
                    else -> "Sạc qua cáp"
                }
                IslandEventManager.post(
                    IslandEvent(ID_CHARGE, IslandKind.CHARGING, "Đang sạc", how, level.toString() + "%", level / 100f, 5000L, false),
                )
            } else if (plugged == 0 && lastPlugged > 0) {
                IslandEventManager.remove(ID_CHARGE)
            }
            if (plugged == 0 && level <= 10 && lastLevel > 10) {
                IslandEventManager.post(
                    IslandEvent(ID_LOW, IslandKind.BATTERY_LOW, "Pin rất yếu", "Cắm sạc ngay", level.toString() + "%", level / 100f, 8000L, false),
                )
            } else if (plugged == 0 && level <= 20 && lastLevel > 20) {
                IslandEventManager.post(
                    IslandEvent(ID_LOW, IslandKind.BATTERY_LOW, "Pin yếu", "Hãy cắm sạc", level.toString() + "%", level / 100f, 6000L, false),
                )
            }
            if (plugged != 0 && level >= 100 && lastLevel in 0..99) {
                IslandEventManager.post(
                    IslandEvent(ID_FULL, IslandKind.BATTERY_FULL, "Pin đầy", "Có thể rút sạc", "100%", 1f, 5000L, false),
                )
            }
        }
        lastPlugged = plugged
        lastLevel = level
    }

    private companion object {
        const val ID_CHARGE = "battery-charge"
        const val ID_LOW = "battery-low"
        const val ID_FULL = "battery-full"
    }
}
