package com.godly.island.island

import android.view.Choreographer
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.spring
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Real frame timing of the last Island morph (measured with Choreographer, not estimated). */
data class TransitionStats(
    val frames: Int,
    val avgMs: Float,
    val p95Ms: Float,
    val worstMs: Float,
    val dropped: Int,
)

/**
 * Animation constants + a tiny frame meter.
 * Grow = lively spring with a little overshoot (iOS feel). Shrink = faster, almost no bounce.
 * Nothing here runs when the Island is not animating, so an idle Island costs no GPU.
 */
object IslandAnimationController {
    val growSpec: SpringSpec<Float> = spring(dampingRatio = 0.74f, stiffness = 360f)
    val shrinkSpec: SpringSpec<Float> = spring(dampingRatio = 0.92f, stiffness = 560f)
    val dualSpec: SpringSpec<Float> = spring(dampingRatio = 0.80f, stiffness = 380f)
    const val COLOR_MS = 300
    val colorEasing = FastOutSlowInEasing

    var lastStats by mutableStateOf<TransitionStats?>(null)
        private set

    private val meter = FrameMeter()

    fun begin() = meter.start()

    fun end() {
        lastStats = meter.stop()
    }

    private class FrameMeter {
        private var running = false
        private var last = 0L
        private val deltas = ArrayList<Long>()

        private val callback = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (!running) return
                if (last != 0L) deltas.add(frameTimeNanos - last)
                last = frameTimeNanos
                Choreographer.getInstance().postFrameCallback(this)
            }
        }

        fun start() {
            if (running) return
            running = true
            last = 0L
            deltas.clear()
            Choreographer.getInstance().postFrameCallback(callback)
        }

        fun stop(): TransitionStats? {
            if (!running) return null
            running = false
            Choreographer.getInstance().removeFrameCallback(callback)
            if (deltas.size < 3) return null
            val sorted = deltas.sorted()
            val median = sorted[sorted.size / 2]
            val p95 = sorted[((sorted.size - 1) * 95) / 100]
            var sum = 0L
            var dropped = 0
            for (d in deltas) {
                sum += d
                if (d > median * 3 / 2) dropped++
            }
            return TransitionStats(
                frames = deltas.size,
                avgMs = sum.toFloat() / deltas.size / 1_000_000f,
                p95Ms = p95 / 1_000_000f,
                worstMs = sorted[sorted.size - 1] / 1_000_000f,
                dropped = dropped,
            )
        }
    }
}
