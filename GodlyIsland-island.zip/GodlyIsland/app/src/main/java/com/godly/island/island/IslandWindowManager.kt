package com.godly.island.island

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import com.godly.island.core.ErrorLog
import kotlin.math.roundToInt

/**
 * Owns the overlay window.
 *
 * Smoothness rule: the window is resized only at the START of a growing morph (before the animation)
 * and at the END of a shrinking one — never per frame — so Android never relayouts a window while the
 * Island animates. The window is as small as the current shape needs, so touches everywhere else go
 * straight to the app underneath.
 *
 * Position: centred on the camera cut-out when Android reports one, otherwise near the top centre;
 * the user can fine-tune with the X/Y sliders.
 */
class IslandWindowManager(private val context: Context) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val dm = context.resources.displayMetrics
    private val main = Handler(Looper.getMainLooper())

    private var view: View? = null
    private var lp: WindowManager.LayoutParams? = null

    private var curW = 140f
    private var curH = 50f
    private var tgtW = 140f
    private var tgtH = 50f

    private var offX = 0f
    private var offY = 0f
    private var miniH = 37f
    private var cutCx: Float? = null
    private var cutCy: Float? = null

    private val shrink = Runnable { applyTarget() }

    private fun px(dp: Float): Int = (dp * dm.density).roundToInt()

    fun attach(v: View) {
        if (view != null) return
        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        val p = WindowManager.LayoutParams(
            px(curW),
            px(curH),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.title = "GodlyIsland"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        lp = p
        view = v
        computePosition(p)
        ViewCompat.setOnApplyWindowInsetsListener(v) { vw, insets ->
            readCutout(vw, insets)
            applyPosition()
            insets
        }
        try {
            wm.addView(v, p)
        } catch (t: Throwable) {
            ErrorLog.add("window", "addView failed: " + (t.message ?: t.javaClass.simpleName))
            view = null
            lp = null
        }
    }

    fun detach() {
        main.removeCallbacks(shrink)
        val v = view ?: return
        try {
            wm.removeView(v)
        } catch (_: Throwable) {
        }
        view = null
        lp = null
    }

    /** The Island needs a window of this size (dp). Grows now, shrinks after the morph. */
    fun request(wDp: Float, hDp: Float) {
        main.removeCallbacks(shrink)
        tgtW = wDp
        tgtH = hDp
        val newW = if (tgtW > curW) tgtW else curW
        val newH = if (tgtH > curH) tgtH else curH
        if (newW != curW || newH != curH) {
            curW = newW
            curH = newH
            applySize()
        }
        if (tgtW < curW || tgtH < curH) {
            main.postDelayed(shrink, 900L) // safety net; normally animationEnded() runs first
        }
    }

    /** The morph finished: now it is safe to shrink the window. */
    fun animationEnded() {
        if (tgtW < curW || tgtH < curH) {
            main.removeCallbacks(shrink)
            applyTarget()
        }
    }

    fun setPosition(offsetXdp: Float, offsetYdp: Float, miniHeightDp: Float) {
        offX = offsetXdp
        offY = offsetYdp
        miniH = miniHeightDp
        applyPosition()
    }

    private fun applyTarget() {
        curW = tgtW
        curH = tgtH
        applySize()
    }

    private fun applySize() {
        val p = lp ?: return
        val v = view ?: return
        val w = px(curW)
        val h = px(curH)
        if (p.width == w && p.height == h) return
        p.width = w
        p.height = h
        update(v, p)
    }

    private fun readCutout(v: View, insets: WindowInsetsCompat) {
        val rects = insets.displayCutout?.boundingRects ?: return
        val top = rects.filter { it.top <= px(60f) }.minByOrNull { it.top } ?: return
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        cutCx = top.exactCenterX() + loc[0]
        cutCy = top.exactCenterY() + loc[1]
    }

    private fun computePosition(p: WindowManager.LayoutParams): Boolean {
        val d = dm.density
        val cy = cutCy ?: (22f * d)
        val cx = cutCx ?: (dm.widthPixels / 2f)
        val x = (cx - dm.widthPixels / 2f + offX * d).roundToInt()
        val y = (cy - miniH * d / 2f + offY * d - WINDOW_MARGIN_DP * d).roundToInt()
        val changed = p.x != x || p.y != y
        p.x = x
        p.y = y
        return changed
    }

    private fun applyPosition() {
        val p = lp ?: return
        val v = view ?: return
        if (computePosition(p)) update(v, p)
    }

    private fun update(v: View, p: WindowManager.LayoutParams) {
        try {
            wm.updateViewLayout(v, p)
        } catch (t: Throwable) {
            ErrorLog.add("window", "updateViewLayout failed: " + (t.message ?: t.javaClass.simpleName))
        }
    }
}

/** A Service is not a LifecycleOwner; Compose in an overlay window needs one. */
class OverlayOwner : LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {
    private val registry = LifecycleRegistry(this)
    private val savedState = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedState.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    fun create() {
        savedState.performRestore(null)
        registry.currentState = Lifecycle.State.CREATED
    }

    fun resume() {
        registry.currentState = Lifecycle.State.RESUMED
    }

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
        store.clear()
    }
}
