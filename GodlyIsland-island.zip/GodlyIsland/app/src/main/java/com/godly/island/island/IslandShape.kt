package com.godly.island.island

/** The five states of the Island. HIDDEN shrinks it to nothing, MINI is also the idle pill. */
enum class IslandShape(val label: String) {
    HIDDEN("Hidden"),
    MINI("Mini"),
    EXPANDED("Expanded"),
    FULL("Full"),
    DUAL("Dual"),
}

/** Distance between the two pills of the Dual Island (the camera sits in the gap). */
const val DUAL_GAP_DP = 52f

/** Transparent margin kept around the pills inside the overlay window. */
const val WINDOW_MARGIN_DP = 4f

/** Size of one pill in dp. For DUAL this is the size of EACH of the two pills. */
data class PillSpec(val w: Float, val h: Float, val dual: Boolean)

fun IslandSettings.specFor(shape: IslandShape, screenWdp: Float): PillSpec {
    val maxW = if (screenWdp > 120f) screenWdp - 16f else 300f
    return when (shape) {
        IslandShape.HIDDEN -> PillSpec(0f, 0f, false)
        IslandShape.MINI -> PillSpec(miniW.coerceAtMost(maxW), miniH, false)
        IslandShape.EXPANDED -> PillSpec(expW.coerceAtMost(maxW), expH, false)
        IslandShape.FULL -> PillSpec(fullW.coerceAtMost(maxW), fullH, false)
        IslandShape.DUAL -> PillSpec((miniW * 1.18f).coerceAtMost((maxW - DUAL_GAP_DP) / 2f), miniH, true)
    }
}

/** Overlay window size (dp) that fits [shape] plus the spring overshoot. */
fun IslandSettings.windowSizeDp(shape: IslandShape, screenWdp: Float): Pair<Float, Float> {
    val s = specFor(shape, screenWdp)
    val hidden = shape == IslandShape.HIDDEN
    val baseW = if (hidden) miniW else if (s.dual) 2f * s.w + DUAL_GAP_DP else s.w
    val baseH = if (hidden) miniH else s.h
    return Pair(baseW * 1.08f + 2f * WINDOW_MARGIN_DP, baseH * 1.08f + 2f * WINDOW_MARGIN_DP)
}
