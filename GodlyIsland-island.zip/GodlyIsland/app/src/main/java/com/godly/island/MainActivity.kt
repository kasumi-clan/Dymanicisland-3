package com.godly.island

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.godly.island.core.GodlyButton
import com.godly.island.core.GodlyCard
import com.godly.island.core.GodlyColors
import com.godly.island.core.GodlyTheme
import com.godly.island.core.SectionTitle
import com.godly.island.island.IslandLauncher
import com.godly.island.island.IslandPreviewControl
import com.godly.island.island.IslandRuntime
import com.godly.island.renderer.IslandMaterial
import com.godly.island.settings.IslandSettingsActivity
import com.godly.island.testing.GodlyIslandTestActivity

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        IslandRuntime.load(this)
        // bring the Island back after the app was closed, if it was on and the permission is still granted
        if (IslandRuntime.settings.enabled && IslandLauncher.hasOverlayPermission(this) && !IslandRuntime.running) {
            IslandLauncher.start(this)
        }
        setContent {
            GodlyTheme {
                HomeScreen(
                    tick = tick,
                    onSettings = { startActivity(Intent(this@MainActivity, IslandSettingsActivity::class.java)) },
                    onTest = { startActivity(Intent(this@MainActivity, GodlyIslandTestActivity::class.java)) },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++
    }
}

@Composable
private fun HomeScreen(tick: Int, onSettings: () -> Unit, onTest: () -> Unit) {
    val context = LocalContext.current
    val running = IslandRuntime.running
    val overlayOk = remember(tick) { IslandLauncher.hasOverlayPermission(context) }
    val material = remember { IslandMaterial.create(context) }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    Box(Modifier.fillMaxSize().background(GodlyColors.Ink)) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("Godly Island", color = GodlyColors.Paper, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Dynamic Island cho Android — kính lỏng nhiều màu, icon tự vẽ.",
                color = GodlyColors.Muted,
                fontSize = 13.sp,
            )

            GodlyCard {
                SectionTitle("Trạng thái")
                Text(
                    if (running) "Island: đang chạy" else "Island: đang tắt",
                    color = if (running) GodlyColors.Ok else GodlyColors.Muted,
                    fontSize = 13.sp,
                )
                Text(
                    if (overlayOk) "Quyền hiển thị trên ứng dụng khác: đã cấp" else "Quyền hiển thị trên ứng dụng khác: CHƯA cấp",
                    color = if (overlayOk) GodlyColors.Ok else GodlyColors.Warn,
                    fontSize = 13.sp,
                )
                Text(
                    "Android API " + Build.VERSION.SDK_INT + " • " + Build.MANUFACTURER + " " + Build.MODEL,
                    color = GodlyColors.Paper,
                    fontSize = 12.sp,
                )
                Text(
                    if (material.ready) "Kính shader GPU: dùng được (" + material.compileMillis + " ms)"
                    else "Kính shader GPU: không dùng được → Canvas (" + (material.error ?: "lỗi") + ")",
                    color = if (material.ready) GodlyColors.Ok else GodlyColors.Warn,
                    fontSize = 12.sp,
                )
            }

            GodlyButton(
                if (running) "Tắt Dynamic Island" else "Bật Dynamic Island",
                {
                    if (running) {
                        IslandPreviewControl.stop()
                        IslandLauncher.stop(context)
                    } else {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                            PackageManager.PERMISSION_GRANTED
                        ) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        IslandLauncher.start(context)
                    }
                },
                Modifier.fillMaxWidth(),
                filled = true,
            )
            GodlyButton("Cài đặt Island (kích thước, kiểu, màu)", onSettings, Modifier.fillMaxWidth())
            GodlyButton("Mở Test Mode", onTest, Modifier.fillMaxWidth())

            GodlyCard {
                SectionTitle("Island đang hiển thị gì thật?")
                Text("Có thật: pin (đang sạc, pin yếu 20% / 10%, pin đầy).", color = GodlyColors.Ok, fontSize = 12.sp)
                Text(
                    "Chưa làm: thông báo, nhạc, cuộc gọi, điều hướng, hẹn giờ, Bluetooth… (phase sau). Test Mode dùng sự kiện giả lập.",
                    color = GodlyColors.Muted,
                    fontSize = 12.sp,
                )
            }
        }
    }
}
