package com.godly.island.island

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.godly.island.events.IslandKind
import com.godly.island.testing.IslandEventSimulator

/** Start / stop the real Island and the Settings preview helper. */
object IslandLauncher {
    fun hasOverlayPermission(context: Context): Boolean = Settings.canDrawOverlays(context)

    /** Opens the system screen where the user grants "Display over other apps". */
    fun openOverlaySettings(context: Context) {
        val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + context.packageName))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
    }

    /** Returns false (and opens the permission screen) when the overlay permission is missing. */
    fun start(context: Context): Boolean {
        if (!hasOverlayPermission(context)) {
            openOverlaySettings(context)
            return false
        }
        IslandRuntime.update(context) { it.copy(enabled = true) }
        ContextCompat.startForegroundService(context, Intent(context, GodlyIslandService::class.java))
        return true
    }

    fun stop(context: Context) {
        IslandRuntime.update(context) { it.copy(enabled = false) }
        context.stopService(Intent(context, GodlyIslandService::class.java))
    }
}

/** Shows a given size on the REAL Island while Settings is open (simulated events only). */
object IslandPreviewControl {
    fun show(shape: IslandShape) {
        IslandEventManager.clearSimulated()
        if (shape == IslandShape.DUAL) {
            for (e in IslandEventSimulator.dualSample()) IslandEventManager.post(e)
        } else if (shape != IslandShape.HIDDEN && shape != IslandShape.MINI) {
            IslandEventManager.post(IslandEventSimulator.sample(IslandKind.MUSIC))
        } else if (shape == IslandShape.MINI) {
            IslandEventManager.post(IslandEventSimulator.sample(IslandKind.NOTIFICATION))
        }
        IslandStateManager.previewShape = shape
    }

    fun stop() {
        IslandStateManager.previewShape = null
        IslandEventManager.clearSimulated()
    }
}
