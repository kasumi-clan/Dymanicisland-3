package com.godly.island.renderer

import android.content.Context
import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.godly.island.core.ErrorLog

/**
 * The Island's liquid-glass body (assets/island_material.agsl).
 * Procedural, single pass, no offscreen layer and no texture reads: while the Island morphs only a
 * few uniforms change per frame. Needs Android 13+; [draw] returns false so the caller can use the
 * Canvas fallback instead (older Android, compile error, or runtime error).
 */
class IslandMaterial private constructor(
    private val backend: IslandAgsl?,
    val error: String?,
    val compileMillis: Long,
) {
    @Volatile
    private var broken = false

    val ready: Boolean get() = backend != null && !broken

    fun draw(
        scope: DrawScope,
        w: Float,
        h: Float,
        radius: Float,
        a: Color,
        b: Color,
        bright: Float,
        lens: Float,
        rimW: Float,
        rimGain: Float,
    ): Boolean {
        val be = backend ?: return false
        if (broken) return false
        return try {
            be.update(w, h, radius, a, b, bright, lens, rimW, rimGain)
            scope.drawRect(brush = be.brush, size = Size(w, h))
            true
        } catch (t: Throwable) {
            broken = true
            ErrorLog.add("island-shader", "Runtime failure: " + (t.message ?: t.javaClass.simpleName))
            false
        }
    }

    companion object {
        private var source: String? = null

        /** Compiles the shader. Never throws. */
        fun create(context: Context): IslandMaterial {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                return IslandMaterial(null, "AGSL needs Android 13+ (API 33)", 0L)
            }
            val t0 = System.nanoTime()
            return try {
                val src = synchronized(this) {
                    source ?: context.applicationContext.assets.open("island_material.agsl")
                        .bufferedReader().use { it.readText() }.also { source = it }
                }
                IslandMaterial(IslandAgsl(src), null, (System.nanoTime() - t0) / 1_000_000)
            } catch (t: Throwable) {
                ErrorLog.add("island-shader", "Compile failed: " + (t.message ?: t.javaClass.simpleName))
                IslandMaterial(null, t.message ?: t.javaClass.simpleName, (System.nanoTime() - t0) / 1_000_000)
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
internal class IslandAgsl(source: String) {
    private val shader = RuntimeShader(source)
    val brush: Brush = ShaderBrush(shader)

    fun update(
        w: Float,
        h: Float,
        radius: Float,
        a: Color,
        b: Color,
        bright: Float,
        lens: Float,
        rimW: Float,
        rimGain: Float,
    ) {
        shader.setFloatUniform("box", 0f, 0f, w, h)
        shader.setFloatUniform("radius", radius)
        shader.setFloatUniform("rimW", rimW)
        shader.setFloatUniform("colA", a.red, a.green, a.blue, 1f)
        shader.setFloatUniform("colB", b.red, b.green, b.blue, 1f)
        shader.setFloatUniform("mixAmt", 1f)
        shader.setFloatUniform("bright", bright)
        shader.setFloatUniform("lens", lens)
        shader.setFloatUniform("rimGain", rimGain)
        shader.setFloatUniform("alphaIn", 1f)
    }
}
