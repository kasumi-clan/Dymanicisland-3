package com.godly.island.island

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class IslandStyle(val label: String) {
    /** Bright, colourful liquid glass (default). */
    GODLY_COLOR("Godly Color"),

    /** Pure black body like the iPhone 14 Pro Max; colour only in icon, bar and text. */
    IPHONE_BLACK("iPhone 14 Pro Max (đen)"),
}

/** Everything the user can tune for the real Island. Sizes are dp. */
data class IslandSettings(
    val enabled: Boolean = false,
    val style: IslandStyle = IslandStyle.GODLY_COLOR,
    val showIdle: Boolean = true,
    val miniW: Float = 126f,
    val miniH: Float = 37f,
    val expW: Float = 316f,
    val expH: Float = 72f,
    val fullW: Float = 352f,
    val fullH: Float = 178f,
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val brightness: Float = 0.6f,
    val lens: Float = 0.85f,
    val useShader: Boolean = true,
) {
    /** Sizes of the iPhone 14 Pro Max Dynamic Island (126x37 idle, 371 wide when expanded). */
    fun withIphonePreset(): IslandSettings = copy(
        style = IslandStyle.IPHONE_BLACK,
        miniW = 126f, miniH = 37f,
        expW = 371f, expH = 84f,
        fullW = 371f, fullH = 176f,
    )
}

class IslandSettingsStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("godly_island_island", Context.MODE_PRIVATE)

    fun load(): IslandSettings {
        val d = IslandSettings()
        return IslandSettings(
            enabled = prefs.getBoolean("enabled", d.enabled),
            style = runCatching {
                IslandStyle.valueOf(prefs.getString("style", null) ?: d.style.name)
            }.getOrDefault(d.style),
            showIdle = prefs.getBoolean("showIdle", d.showIdle),
            miniW = prefs.getFloat("miniW", d.miniW),
            miniH = prefs.getFloat("miniH", d.miniH),
            expW = prefs.getFloat("expW", d.expW),
            expH = prefs.getFloat("expH", d.expH),
            fullW = prefs.getFloat("fullW", d.fullW),
            fullH = prefs.getFloat("fullH", d.fullH),
            offsetX = prefs.getFloat("offsetX", d.offsetX),
            offsetY = prefs.getFloat("offsetY", d.offsetY),
            brightness = prefs.getFloat("brightness", d.brightness),
            lens = prefs.getFloat("lens", d.lens),
            useShader = prefs.getBoolean("useShader", d.useShader),
        )
    }

    fun save(s: IslandSettings) {
        prefs.edit()
            .putBoolean("enabled", s.enabled)
            .putString("style", s.style.name)
            .putBoolean("showIdle", s.showIdle)
            .putFloat("miniW", s.miniW)
            .putFloat("miniH", s.miniH)
            .putFloat("expW", s.expW)
            .putFloat("expH", s.expH)
            .putFloat("fullW", s.fullW)
            .putFloat("fullH", s.fullH)
            .putFloat("offsetX", s.offsetX)
            .putFloat("offsetY", s.offsetY)
            .putFloat("brightness", s.brightness)
            .putFloat("lens", s.lens)
            .putBoolean("useShader", s.useShader)
            .apply()
    }
}

/** Process-wide live state shared by the Service (overlay), Settings and Test Mode. Main thread only. */
object IslandRuntime {
    var settings by mutableStateOf(IslandSettings())
    var running by mutableStateOf(false)

    fun load(context: Context) {
        settings = IslandSettingsStore(context).load()
    }

    fun persist(context: Context) {
        IslandSettingsStore(context).save(settings)
    }

    /** Applies [block] immediately (the real Island reacts live); writes to disk when [save] is true. */
    fun update(context: Context, save: Boolean = true, block: (IslandSettings) -> IslandSettings) {
        settings = block(settings)
        if (save) persist(context)
    }
}
