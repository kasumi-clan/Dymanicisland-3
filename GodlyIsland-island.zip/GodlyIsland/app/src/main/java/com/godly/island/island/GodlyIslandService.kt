package com.godly.island.island

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.godly.island.MainActivity
import com.godly.island.R
import com.godly.island.battery.BatteryEventSource
import com.godly.island.core.ErrorLog

/**
 * Foreground service that hosts the real Island in an overlay window.
 * Real events today: battery (charging / low / full). Notifications, music, calls come in the next phases.
 */
class GodlyIslandService : Service() {
    private var windowManager: IslandWindowManager? = null
    private var owner: OverlayOwner? = null
    private var composeView: ComposeView? = null
    private var battery: BatteryEventSource? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (!Settings.canDrawOverlays(this)) {
            ErrorLog.add("service", "Missing overlay permission; stopping")
            IslandRuntime.running = false
            stopSelf()
            return START_NOT_STICKY
        }
        if (composeView == null) showOverlay()
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Godly Island", NotificationManager.IMPORTANCE_LOW),
            )
        }
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val stop = PendingIntent.getService(
            this,
            1,
            Intent(this, GodlyIslandService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_island)
            .setContentTitle("Godly Island đang chạy")
            .setContentText("Nhấn để mở cài đặt")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_island), "Tắt Island", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun showOverlay() {
        IslandRuntime.load(this)
        val wmgr = IslandWindowManager(this)
        val own = OverlayOwner()
        own.create()
        val cv = ComposeView(this)
        cv.setViewTreeLifecycleOwner(own)
        cv.setViewTreeSavedStateRegistryOwner(own)
        cv.setViewTreeViewModelStoreOwner(own)
        cv.setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindow)
        cv.setContent {
            val s = IslandRuntime.settings
            LaunchedEffect(s.offsetX, s.offsetY, s.miniH) { wmgr.setPosition(s.offsetX, s.offsetY, s.miniH) }
            LaunchedEffect(s.showIdle) { IslandStateManager.onSettingsChanged() }
            IslandView(
                settings = s,
                shape = IslandStateManager.shape,
                events = IslandEventManager.events,
                topPaddingDp = WINDOW_MARGIN_DP,
                onWindowNeeds = { w, h -> wmgr.request(w, h) },
                onTransitionEnd = { wmgr.animationEnded() },
                onTap = { IslandStateManager.onTap() },
                onLongPress = { IslandStateManager.onLongPress() },
                onSwipeUp = { IslandStateManager.onSwipeUp() },
            )
        }
        windowManager = wmgr
        owner = own
        composeView = cv
        wmgr.attach(cv)
        own.resume()
        IslandStateManager.onSettingsChanged()
        battery = BatteryEventSource(this).also { it.start() }
        IslandRuntime.running = true
    }

    override fun onDestroy() {
        battery?.stop()
        battery = null
        composeView?.disposeComposition()
        windowManager?.detach()
        windowManager = null
        owner?.destroy()
        owner = null
        composeView = null
        IslandEventManager.clearAll()
        IslandRuntime.running = false
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.godly.island.action.STOP"
        private const val CHANNEL_ID = "godly_island_service"
        private const val NOTIF_ID = 4242
    }
}
