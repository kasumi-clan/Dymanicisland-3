package com.godly.island.events

/** What kind of thing the Island is showing. Each kind has its own hand-drawn icon and colour. */
enum class IslandKind(val label: String) {
    CALL_INCOMING("Incoming call"),
    CALL_ONGOING("Ongoing call"),
    MUSIC("Music"),
    BATTERY_LOW("Battery low"),
    BATTERY_FULL("Battery full"),
    CHARGING("Charging"),
    NOTIFICATION("Notification"),
    TIMER("Timer"),
    NAVIGATION("Navigation"),
    BLUETOOTH("Bluetooth"),
    DOWNLOAD("Download"),
    AI_PROCESSING("AI processing"),
}

/**
 * One thing the Island can show.
 * [value] = short text for the compact / right-hand side ("02:14", "68%").
 * [ttlMs] = auto-remove after this many ms (0 = stays until removed).
 * [simulated] = produced by Test Mode only; never a real notification or call.
 */
data class IslandEvent(
    val id: String,
    val kind: IslandKind,
    val title: String,
    val subtitle: String,
    val value: String? = null,
    val progress: Float? = null,
    val ttlMs: Long = 0L,
    val simulated: Boolean,
)
