# Changelog

## 0.2.0-island
- **Island thật**: overlay + foreground service (`GodlyIslandService`), cửa sổ nhỏ đúng cỡ, tự căn lỗ camera (nếu Android báo), chỉnh ngang/dọc.
- **Chỉnh kích thước**: Mini / Expanded / Full (ngang + cao), Dual tự suy ra; có xem trước ngay trên Island thật.
- **Kiểu iPhone 14 Pro Max (đen)** + nút áp cỡ iPhone (126x37 nhỏ, 371 rộng khi mở).
- **Icon tự vẽ** cho mọi chức năng (cuộc gọi đến/đang gọi, nhạc, pin yếu/đầy/sạc, thông báo, hẹn giờ, điều hướng, Bluetooth, tải xuống, AI). Hết emoji.
- **Màu sáng**: mỗi chức năng có 2 màu riêng, thân kính nhiều màu, chữ có bóng nhẹ để dễ đọc.
- **Sửa icon "lún"**: icon/lề tính theo chiều cao viên + độ cong đầu viên; nội dung dùng kích thước cuối nên không bị cắt/ép khi chuyển Mini ↔ Dual ↔ Full.
- **Bỏ**: ripple (gợn sóng) và bóng láng quét khi bấm/hiện ra.
- **Giữ + thêm**: kính "hút vào" kiểu Godly-Watermark, nay tính thủ tục trong một lần vẽ (rẻ hơn nhiều); hgiới hạn dải lens theo cạnh ngắn để tránh nếp gấp ở viên cao.
- **Hiệu ứng hiện ra**: pop-in lò xo, chuyển màu mượt, nội dung hiện trễ 80 ms (scale + fade bằng GPU).
- **Sự kiện thật đầu tiên**: pin (BatteryManager, không cần quyền).
- Test Mode dùng đúng `IslandView` của Island thật; thêm số đo chuyển cảnh (Choreographer).
